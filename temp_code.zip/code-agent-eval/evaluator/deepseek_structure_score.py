import openai
import os

# 替换为你的 DeepSeek key
openai.api_key = os.getenv("DEEPSEEK_API_KEY")

# DeepSeek 的 API 地址
openai.base_url = "https://api.deepseek.com/v1"

def score_structure(user_code: str) -> dict:
    prompt = f"""
你是一位代码审阅专家，请对下面的 Python 函数代码进行结构性评估。

代码如下：

```
{user_code}
```


请根据以下标准评分（满分10分）：
1. 结构清晰度 clarity（是否逻辑分明、缩进合理）
2. 命名规范 naming（变量命名是否语义明确）
3. 模块化 modularity（是否使用函数/类划分逻辑、避免重复）

请返回 JSON 格式，如下：
{{
  "clarity": 8,
  "naming": 9,
  "modularity": 7,
  "suggestions": "建议将判断逻辑拆分为子函数，增强可读性。"
}}
"""

    try:
        print("🟡 正在调用 DeepSeek...")
        response = openai.ChatCompletion.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3
        )
        content = response["choices"][0]["message"]["content"]
        print("🔁 LLM 回复内容：", content)
        result = eval(content) if content.strip().startswith("{") else {}
        return result
    except Exception as e:
        print("❌ DeepSeek 错误详情：", traceback.format_exc())
        return {
            "clarity": 0,
            "naming": 0,
            "modularity": 0,
            "suggestions": "DeepSeek 评分失败，请检查模型名称和 base_url 设置。"
        }
