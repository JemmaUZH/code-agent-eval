import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "evaluator")))

import streamlit as st
import json
from run_test import run_test
from deepseek_structure_score import score_structure




# Load all tasks from a single JSON array file
def load_task(task_id):
    with open("tasks/tasks_game_eval.json", "r") as f:
        all_tasks = json.load(f)
        for task in all_tasks:
            if task["id"] == task_id:
                return task
    return None

st.set_page_config(page_title="Code Agent 代码评测系统", layout="wide")
st.title("🤖 Code Agent 自动代码评测系统")

# Sidebar for task selection
st.sidebar.header("选择任务")
task_options = ["game_001", "game_002", "game_003", "game_004", "game_005"]
task_id = st.sidebar.selectbox("任务编号", task_options)
task_data = load_task(task_id)

st.subheader(f"任务名称：{task_data['title']}")
st.markdown(task_data["description"])

user_code = st.text_area("✍️ 粘贴你生成的 Python 函数代码", height=300)

if st.button("🚀 开始评测"):
    with st.spinner("评测中，请稍候..."):
        test_result = run_test(user_code, task_data["test_code"])
        structure_score = score_structure(user_code)

        st.success("✅ 评测完成！")

        st.markdown("### 🧪 测试结果")
        st.write("是否通过测试：", "✅ 是" if test_result["passed"] else "❌ 否")
        if not test_result["passed"]:
            st.write("错误信息：", test_result["error"])

        st.markdown("### 📊 结构评分")
        st.write("结构清晰度：", structure_score["clarity"]) 
        st.write("命名规范：", structure_score["naming"]) 
        st.write("模块化程度：", structure_score["modularity"])

        st.markdown("### 💡 优化建议")
        st.markdown(structure_score["suggestions"])
